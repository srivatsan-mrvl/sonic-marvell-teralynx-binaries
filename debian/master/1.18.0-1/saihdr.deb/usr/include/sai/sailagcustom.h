/**
 *copyright (c) 2025 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 *    @file    sailagcustom.h
 *
 * @brief   This module defines custom attributes for the Switch Abstraction Interface (SAI)
 */

#ifndef __SAILAGCUSTOM_H_
#define __SAILAGCUSTOM_H_

#include <sailag.h>
#include <saitypes.h>

/**
 * @brief SAI lag custom attribute
 */
typedef enum _sai_lag_attr_custom_t
{

    /**
     * @brief SAI ECMP default hash offset
     *
     * When set, the output of the ECMP hash calculation will be rotated right
     * by the specified number of bits.
     *
     * @type sai_uint8_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_LAG_ATTR_CUSTOM_DEFAULT_HASH_OFFSET = SAI_LAG_ATTR_CUSTOM_RANGE_START,

}sai_lag_attr_custom_t;

#endif /* __SAILAGCUSTOM_H_ */
