/**
 *copyright (c) 2026 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 *    @file    saisrv6custom.h
 *
 * @brief   This module defines custom attributes for the Switch Abstraction Interface (SAI)
 */

#ifndef __SAISRV6CUSTOM_H_
#define __SAISRV6CUSTOM_H_

#include <saisrv6.h>
#include <saitypes.h>

/**
 * @brief SAI srv6 custom attribute
 */
typedef enum _sai_my_sid_entry_attr_custom_t
{
    /**
     * @brief User defined trap object ID for trap/log actions
     *
     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_HOSTIF_USER_DEFINED_TRAP
     * @default SAI_NULL_OBJECT_ID
     */
    SAI_MY_SID_ENTRY_ATTR_CUSTOM_TRAP_ID = SAI_MY_SID_ENTRY_ATTR_CUSTOM_RANGE_START,
    SAI_MY_SID_ENTRY_ATTR_CUSTOM_RANGE_MAX,

}sai_my_sid_entry_attr_custom_t;

#endif /* __SAISRV6CUSTOM_H_ */
