/**
 *copyright (c) 2024 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 *    @file    saitypescustom.h
 *
 * @brief   This module defines custom of the Switch Abstraction Interface (SAI)
 */

#ifndef __SAITYPESCUSTOM_H_
#define __SAITYPESCUSTOM_H_

#include <saitypes.h>

/**
 *  @brief SAI object type custom trap
 */
typedef enum _sai_hostif_trap_type_custom_t
{
    /**
     * @brief Custom trap to perform Flood Control on Broadcast,
     * Unknown Unicast and Multicast traffic per Traffic Class
     * (default packet action is forward)
     */
    SAI_HOSTIF_TRAP_TYPE_CUSTOM_TC_FLOOD_CONTROL_DISCARD = SAI_HOSTIF_TRAP_TYPE_SWITCH_CUSTOM_RANGE_BASE + 0x1,

    /**
     * @brief Peer Delay PTP traffic. Conditions are
     * ((EtherType = 0x88F7 or UDP dst port == 319 or UDP dst port == 320)
     * and (PTP messageType ==  0x2 or PTP messageType == 0x3 or PTP messageType == 0x10))
     * Recommended priority: Higher than SAI_HOSTIF_TRAP_TYPE_PTP
     * (default packet action is drop)
     */
    SAI_HOSTIF_TRAP_TYPE_CUSTOM_PTP_PEER_DELAY = SAI_HOSTIF_TRAP_TYPE_SWITCH_CUSTOM_RANGE_BASE + 0x2,

    /*
     * Description:
     * Custom hostif trap to handle unknown source MAC learn packets or MAC move packets.
     * When an unknown or moved source MAC is detected on a port, this trap ensures the
     * packet is sent to the CPU for processing. The default packet action is FORWARD,
     * but can be overridden to TRAP as needed.
     *
     * Usage:
     * - Create a hostif trap group with an assigned CPU queue.
     * - Bind this trap type (SAI_HOSTIF_TRAP_TYPE_CUSTOM_FWD_L2_SRC_MISS_MOVE)
     *   to the group with packet action set to TRAP.
     *
     */
    SAI_HOSTIF_TRAP_TYPE_CUSTOM_FWD_L2_SRC_MISS_MOVE = SAI_HOSTIF_TRAP_TYPE_SWITCH_CUSTOM_RANGE_BASE + 0x3,


    /*
     * Description:
     * Custom hostif trap to handle SRV6 pipeline lookup failure packets, such as
     * header checksum, TTL expiration, SRH processing errors, this trap ensures the
     * packet is sent to the CPU for processing. The default packet action is DROP,
     * but can be overridden to TRAP as needed.
     *
     * Usage:
     * - Create a hostif trap group with an assigned CPU queue.
     * - Bind this trap type (SAI_HOSTIF_TRAP_TYPE_CUSTOM_PIPELINE_DISCARD_SRV6)
     *   to the group with packet action set to TRAP.
     *
     */
    SAI_HOSTIF_TRAP_TYPE_CUSTOM_PIPELINE_DISCARD_SRV6 = SAI_HOSTIF_TRAP_TYPE_SWITCH_CUSTOM_RANGE_BASE + 0x4,
}sai_hostif_trap_type_custom_t;


/**
 * @brief Attribute data for #SAI_SWITCH_ATTR_CUSTOM_PTP_CLOCK_TYPE
 */
typedef enum _sai_switch_custom_ptp_clock_type_t
{
    /** Do not set PTP Clock */
    SAI_SWITCH_CUSTOM_PTP_CLOCK_TYPE_NONE,

    /** Boundary Clock */
    SAI_SWITCH_CUSTOM_PTP_CLOCK_TYPE_BOUNDARY,

    /** Ordinary Clock */
    SAI_SWITCH_CUSTOM_PTP_CLOCK_TYPE_ORDINARY,

    /** End to End Transparent Clock */
    SAI_SWITCH_CUSTOM_PTP_CLOCK_TYPE_TRANSPARENT_E2E,

    /** Peer to Peer Transparent Clock */
    SAI_SWITCH_CUSTOM_PTP_CLOCK_TYPE_TRANSPARENT_P2P,

} sai_switch_custom_ptp_clock_type_t;


/**
 * @brief SAI object type custom acl action
 */
typedef enum _sai_acl_action_type_custom_t
{
    /** Bind a TAM object */
    SAI_ACL_ACTION_TYPE_CUSTOM_TAM_OBJECT = SAI_ACL_ACTION_TYPE_CUSTOM_RANGE_BASE,

    /** Set metadata to carry forward to next ACL stage */
    SAI_ACL_ACTION_TYPE_CUSTOM_SET_ACL_META_DATA_2

}sai_acl_action_type_custom_t;

/**
 * @brief custom Attribute data for SAI_ACL_TABLE_ATTR_SUPPORTED_MATCH_TYPE
 */
typedef enum _sai_acl_table_supported_match_type_custom_t
{

    /** Ternary and Exact */
    SAI_ACL_TABLE_CUSTOM_SUPPORTED_MATCH_TYPE_TERNARY_AND_EXACT = SAI_ACL_TABLE_SUPPORTED_MATCH_TYPE_CUSTOM_RANGE_BASE,

} sai_acl_table_supported_match_type_custom_t;

/**
 * @brief Enum defining custom reporting modes.
 */
typedef enum _sai_tam_report_mode_custom_t
{

    /** Report in a probabilistic mode, one report is sent in n events */
    SAI_TAM_REPORT_MODE_CUSTOM_PROBABILISTIC = SAI_TAM_REPORT_MODE_CUSTOM_RANGE_BASE,

    /** Report using microburst mode, specifying avg rate (packets/sec) and max number of reports per microburst event */
    SAI_TAM_REPORT_MODE_CUSTOM_MICROBURST

} sai_tam_report_mode_custom_t;

/**
 * @brief TAM Telemetry custom Math Function types
 */
typedef enum _sai_tam_tel_math_func_type_custom_t
{

    /** Minimum */
    SAI_TAM_TEL_MATH_FUNC_TYPE_CUSTOM_MIN = SAI_TAM_TEL_MATH_FUNC_TYPE_CUSTOM_RANGE_BASE,

    /** Maximum */
    SAI_TAM_TEL_MATH_FUNC_TYPE_CUSTOM_MAX

} sai_tam_tel_math_func_type_custom_t;

/**
 * @brief Host interface custom TX type
 */
typedef enum _sai_hostif_tx_type_custom_t
{

    /** TX packet goes to the switch ASIC processing pipeline for PTP to decide the output port */
    SAI_HOSTIF_TX_TYPE_CUSTOM_PIPELINE_PTP = SAI_HOSTIF_TX_TYPE_CUSTOM_RANGE_BASE,

} sai_hostif_tx_type_custom_t;

#endif /* __SAITYPESCUSTOM_H_ */
