/**
 *copyright (c) 2024 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 *    @file    saibuffercustom.h
 *
 * @brief   This module defines custom of the Switch Abstraction Interface (SAI)
 */

#ifndef __SAIBUFFERCUSTOM_H_
#define __SAIBUFFERCUSTOM_H_

#include <saibuffer.h>
#include <saitypes.h>


/**
 * @brief SAI buffer pool stat custom
 */
typedef enum _sai_buffer_pool_stat_custom_t
{
    /** Get current pool occupancy in cells [uint64_t] */
    SAI_BUFFER_POOL_STAT_CUSTOM_CURR_OCCUPANCY_CELLS = SAI_BUFFER_POOL_STAT_CUSTOM_RANGE_BASE,

    /** Get watermark pool occupancy in cells [uint64_t] */
    SAI_BUFFER_POOL_STAT_CUSTOM_WATERMARK_CELLS = SAI_BUFFER_POOL_STAT_CUSTOM_RANGE_BASE + 1,

    /** Custom range end */
    SAI_BUFFER_POOL_STAT_CUSTOM_RANGE_END

}sai_buffer_pool_stat_custom_t;

#endif /* __SAIBUFFERCUSTOM_H_ */
