/**
 * Copyright (c) 2014 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 * @file    saipolicercustom.h
 *
 * @brief   This module defines SAI QOS Policer interface custom attributes
 */

#if !defined (__SAIPOLICERCUSTOM_H_)
#define __SAIPOLICERCUSTOM_H_

#include <saipolicer.h>
#include <saitypes.h>

/**
 * @brief Enum defining Policer Attributes
 */
typedef enum _sai_policer_attr_custom_t
{
    /**
     * @brief Actual committed burst size bytes/packets programmed
     * in the hardware based on SAI_POLICER_ATTR_METER_TYPE
     *
     * @type sai_uint64_t
     * @flags READ_ONLY
     */
    SAI_POLICER_ATTR_CUSTOM_ACTUAL_CBS = SAI_POLICER_ATTR_CUSTOM_RANGE_START,

    /**
     * @brief Actual committed information rate BPS/PPS programmed
     * in the hardware based on SAI_POLICER_ATTR_METER_TYPE
     *
     * @type sai_uint64_t
     * @flags READ_ONLY
     */
    SAI_POLICER_ATTR_CUSTOM_ACTUAL_CIR = SAI_POLICER_ATTR_CUSTOM_RANGE_START + 0x1,

    /**
     * @brief Actual peak burst size bytes/packets programmed
     * in the hardware based on SAI_POLICER_ATTR_METER_TYPE
     *
     * @type sai_uint64_t
     * @flags READ_ONLY
     */
    SAI_POLICER_ATTR_CUSTOM_ACTUAL_PBS = SAI_POLICER_ATTR_CUSTOM_RANGE_START + 0x2,

    /**
     * @brief Actual peak information rate BPS/PPS based programmed
     * in the hardware based on SAI_POLICER_ATTR_METER_TYPE
     *
     * @type sai_uint64_t
     * @flags READ_ONLY
     */
    SAI_POLICER_ATTR_CUSTOM_ACTUAL_PIR = SAI_POLICER_ATTR_CUSTOM_RANGE_START + 0x3,

} sai_policer_attr_custom_t;


/**
 * @}
 */
#endif /** __SAIPOLICERCUSTOM_H_ */
