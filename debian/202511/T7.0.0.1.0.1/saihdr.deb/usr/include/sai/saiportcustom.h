/**
 *copyright (c) 2024 Microsoft Open Technologies, Inc.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABILITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 *    Microsoft would like to thank the following companies for their review and
 *    assistance with these files: Intel Corporation, Mellanox Technologies Ltd,
 *    Dell Products, L.P., Facebook, Inc., Marvell International Ltd.
 *
 *    @file    saiportcustom.h
 *
 * @brief   This module defines custom of the Switch Abstraction Interface (SAI)
 */

#ifndef __SAIPORTCUSTOM_H_
#define __SAIPORTCUSTOM_H_

#include <saiport.h>
#include <saitypes.h>


/**
 * @brief SAI port custom attribute
 */
typedef enum _sai_port_attr_custom_t
{
    /**
     * @brief Update dot1p of outgoing packets
     *
     * Enabling this on an ingress port to mark the dot1p at the outgoing
     * port with the respective SAI_PORT_ATTR_QOS_TC_AND_COLOR_TO_DOT1P_MAP
     *
     * @type bool
     * @flags CREATE_AND_SET
     * @default true
     */
    SAI_PORT_ATTR_CUSTOM_UPDATE_DOT1P = SAI_PORT_ATTR_CUSTOM_RANGE_START + 1,

    /**
     * @brief Estimate of the one-way (From port to neighbor) link propagation
     *        delay in nanoseconds.
     *
     * This shall be added to PTP header correction-field along with resident time in Peer Delay Mechanism.
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default = (0)
     * @validonly SAI_PORT_ATTR_CUSTOM_CUSTOM_PTP_CLOCK_TYPE == SAI_SWITCH_PTP_CLOCK_TYPE_TRANSPARENT_P2P
     */
    SAI_PORT_ATTR_CUSTOM_PTP_PEER_MEAN_PATH_DELAY,

    /**
     * @breif KS Specific Attribute for ECMP path select
     *
     * @type sai_ip4_t
     * @flags READ_ONLY
     * @objects
     */
    SAI_PORT_ATTR_FIELD_SRC_IP,

    /**
     * @brief KS Specific Attribute for ECMP path select
     *
     * @type sai_ip4_t
     * @flags READ_ONLY
     */
    SAI_PORT_ATTR_FIELD_DST_IP,

    /**
     * @brief KS Specific Attribute for ECMP path select
     *
     * @type sai_ip6_t
     * @flags READ_ONLY
     */
    SAI_PORT_ATTR_FIELD_SRC_IPV6,

    /**
     * @brief KS Specific Attribute for ECMP path select
     *
     * @type sai_ip6_t
     * @flags READ_ONLY
     */
    SAI_PORT_ATTR_FIELD_DST_IPV6,

    /**
     * @brief KS Specific Attribute for ECMP path select
     *
     * @type  sai_uint32_t
     * @flags READ_ONLY
     * @objects
     */
    SAI_PORT_ATTR_FIELD_L4_SRC_PORT,

   /**
    * @brief KS Specific Attribute for ECMP path select
    *
    * @type  sai_uint32_t
    * @flags READ_ONLY
    */
   SAI_PORT_ATTR_FIELD_L4_DST_PORT,

   /**
    * @brief KS Specific Attribute for ECMP path select
    *
    * @type sai_uint16_t
    * @flags READ_ONLY
    */
    SAI_PORT_ATTR_FIELD_IP_PROTOCOL,

   /**
    * @brief KS Specific Attribute for ECMP path select
    *
    * @type sai_object_id_t
    * @flags READ_ONLY
    */
    SAI_PORT_ATTR_FIELD_EGRESS_PORT,

    /**
     * @brief Enable TC -> Queue MAP on port for Multicast flows
     *
     * Map id = #SAI_NULL_OBJECT_ID to have same map for Multicast as Unicast.
     *
     * @type sai_object_id_t
     * @flags CREATE_AND_SET
     * @objects SAI_OBJECT_TYPE_QOS_MAP
     * @allownull true
     * @default SAI_NULL_OBJECT_ID
     */
    SAI_PORT_ATTR_CUSTOM_QOS_TC_TO_QUEUE_MAP_MULTICAST,

    /**
     * @brief SAI ECMP default hash enable/disable
     *
     * Use port level hash configs when set to true
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_PORT_ATTR_CUSTOM_ECMP_DEFAULT_HASH_ENABLE,

    /**
     * @brief SAI ECMP default hash algorithm
     *
     * @type sai_hash_algorithm_t
     * @flags CREATE_AND_SET
     * @default SAI_HASH_ALGORITHM_CRC
     */
    SAI_PORT_ATTR_CUSTOM_ECMP_DEFAULT_HASH_ALGORITHM,

    /**
     * @brief SAI ECMP default hash seed
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_PORT_ATTR_CUSTOM_ECMP_DEFAULT_HASH_SEED,

    /**
     * @brief SAI ECMP default hash offset
     *
     * When set, the output of the ECMP hash calculation will be rotated right
     * by the specified number of bits.
     *
     * @type sai_uint8_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_PORT_ATTR_CUSTOM_ECMP_DEFAULT_HASH_OFFSET,

    /**
     * @brief SAI LAG default hash enable/disable
     *
     * Use port level hash configs when set to true
     * @type bool
     * @flags CREATE_AND_SET
     * @default false
     */
    SAI_PORT_ATTR_CUSTOM_LAG_DEFAULT_HASH_ENABLE,

    /**
     * @brief SAI LAG default hash algorithm
     *
     * @type sai_hash_algorithm_t
     * @flags CREATE_AND_SET
     * @default SAI_HASH_ALGORITHM_CRC
     */
    SAI_PORT_ATTR_CUSTOM_LAG_DEFAULT_HASH_ALGORITHM,

    /**
     * @brief SAI LAG default hash seed
     *
     * @type sai_uint32_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_PORT_ATTR_CUSTOM_LAG_DEFAULT_HASH_SEED,

    /**
     * @brief SAI LAG default hash offset
     *
     * When set, the output of the ECMP hash calculation will be rotated right
     * by the specified number of bits.
     *
     * @type sai_uint8_t
     * @flags CREATE_AND_SET
     * @default 0
     */
    SAI_PORT_ATTR_CUSTOM_LAG_DEFAULT_HASH_OFFSET,

}sai_port_attr_custom_t;


/**
 * @brief SAI port stat custom
 */
typedef enum _sai_port_stat_custom_t
{
    /** Port stats custom user discards (eg. per-TC BUM flood control drops) */
    SAI_PORT_STAT_CUSTOM_IN_USER_DROPPED_PACKETS = SAI_PORT_STAT_CUSTOM_RANGE_BASE,

    /** Custom Port stat ether stats TX packets */
    SAI_PORT_STAT_CUSTOM_IF_OUT_PKTS,

    /** Custom port stat to get port occupancy/utilization percentage */
    SAI_PORT_STAT_CUSTOM_OUT_CURR_OCCUPANCY_LEVEL,

    /** Port storm control dropped packets for (Flood, Broadcast and Multicast storms)*/
    SAI_PORT_STAT_CUSTOM_ALL_STORM_CONTROL_DROPPED_PKTS,

    /** SAI port stat SRV6 in discards */
    SAI_PORT_STAT_CUSTOM_SRV6_IN_DISCARDS,

    /** SAI port stat for tc flood control discards */
    SAI_PORT_STAT_CUSTOM_TC_FLOOD_CONTROL_DISCARDS,

    /** Port stat custom range end */
    SAI_PORT_STAT_CUSTOM_RANGE_END

}sai_port_stat_custom_t;

#endif /* __SAIPORTCUSTOM_H_ */
